Nerdvana patch kit for FTB Ultimate (1.1.2)
===========================================

Install
-------

* Select the FTB Ultimate pack (v1.1.2) in the FTB Launcher
* Click 'Edit Mods'
* Use "Open Folder" to open the mod/coremod folder in Explorer. Move up one folder.
* Copy scala-library.jar from Libs into lib/
* Copy files in Mods to mods/
* Copy files in Coremods to coremods/
* Return to Launcher Edit Mods dialog
* Add all files in Jar to jar tab using 'Add Mod'
* Launch

Optifine Users
--------------

The default zoom key clashes with the SM Grab command. Change these in Controls as with any normal Minecraft keybind.
